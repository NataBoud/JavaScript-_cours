export class Voiture {
    constructor(marque, modele, vitesse) {
        this.marque = marque
        this.modele = modele
        this.vitesse = vitesse
    }

    acceleration() {
        this.vitesse += 10
        console.log(`La voiture ${this.marque} va accélérer`);
    }

    diminuation() {
        this.vitesse -= 5
        console.log(`La voiture ${this.marque} et tourner `);
   }

}