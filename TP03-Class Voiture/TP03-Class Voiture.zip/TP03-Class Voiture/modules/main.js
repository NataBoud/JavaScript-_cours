import { Voiture } from "./classes/Voiture.js";

let voiture1 = new Voiture("BMV", "Serie1", 80)
let voiture2 = new Voiture("Mercedes", "GLB", 100)

voiture1.acceleration()
voiture1.acceleration()
voiture1.acceleration()

voiture2.diminuation()
voiture2.diminuation()
