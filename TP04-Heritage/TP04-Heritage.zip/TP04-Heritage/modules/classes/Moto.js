import { Vehicule } from "./Vehicule.js";

export class Moto extends Vehicule {
    constructor(marque, modele, kilometrage, annee) {
        super(marque, modele, kilometrage, annee)
    }

    Display() {
        super.Display()
        let viewMoto = `Moto : ${ this.marque} - ${this.modele} - ${this.kilometrage}km - ${this.annee}`
        return viewMoto
    }
}