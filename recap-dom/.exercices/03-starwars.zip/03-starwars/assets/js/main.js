/*
    Exercice 03

    Vai l'API public de Starwars API, réalisez une application permettant aux utilisateurs de voir les informations de base pour chaqu'un des 6 films de base de la sage Star Wars (les originaux, pas les Disney). 

    Chacun de ces films va servir dans l'affichage à générer un bouton, qui, lorsque cliqué, va effectuer une requête à l'API dans le but de peupler un affichage (via des <li> ou dans une carte à la Bootstrap (vous pouvez en faire le design en CSS pur bien sur).

    Il vous faudra donc:
        * Faire une requête permettant d'avoir tous les titres des films de la saga Star Wars
        * Un bouton avec comme texte le titre du film pour chaque film de la saga 
        * Déclencher une requête spécifique au film au moment du clic sur le bouton de l'un des films de la saga
        * Afficher les informations dans un endroit de la page une fois finie
*/

const recupInfosFilmsStarWars = async (url) => {
  try {
    const response = await fetch(url);
    const data = await response.json();
    const mesResultats = data.results;
    // console.log(mesResultats);
    return mesResultats.map((film) => film.title);
  } catch (err) {
    console.error(err);
  }
};

const recupInfosFilm = async (url) => {
  try {
    const response = await fetch(url);
    const data = await response.json();
    const mesResultats = data.results;
    return mesResultats.map(
      (film) => film.director + film.producer + film.release_date
    );
  } catch (err) {
    console.error(err);
  }
};

document.addEventListener("DOMContentLoaded", () => {
  const resltUL = document.querySelector("ul#resultat");
  const resltSPAN = document.querySelector("span#info");
  const main = document.querySelector("main");
  const chargementPage = document.createElement("h1");
  chargementPage.textContent = "Loading...";
  main.appendChild(chargementPage);

  const BASE_STARWARS_API_URL = "https://swapi.dev/api/";
  const url = BASE_STARWARS_API_URL + "films";

  let tableauTitresFilms = [];
  recupInfosFilmsStarWars(url).then((titres) => {
    tableauTitresFilms = titres;

    for (const element of tableauTitresFilms) {
      const newLIElement = document.createElement("li");
      newLIElement.textContent = element;
      resltUL.appendChild(newLIElement);

      newLIElement.addEventListener("click", () => {
        let tableauFilmURL = [];
        recupInfosFilm(url).then((info) => {
          tableauFilmURL = info;
          console.log(tableauFilmURL);
        });
      });
    }
    chargementPage.innerHTML = "";
  });
});
