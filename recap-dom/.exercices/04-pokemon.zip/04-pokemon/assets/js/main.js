/*
    Exercice 04 

    Réaliser une application permettant à un utilisateur de rechercher les informations d'un pokémon. 

    Pour cela, il aura à sa disposition deux <select>: 
      * Le premier select servira à sélectionner la région. De base, il est vide, mais via le code Javascript il sera peuplé d'options permettant de choisir la région voulue. Une fois l'option choisie, on ira peupler le seconde select avec les pokémons disponibles dans cette région
    * Un autre select peremettant de choisir un pokémon parmi une liste peuplée en fonction de sa région d'origine (Kanto, Aloha, Jotho, etc...). Lors de la sélection d'un pokémon dans ce select, on ira rechercher les informations du pokémon pour les afficher dans un élément HTML prévu pour
    

    Une fois les deux requêtes faites, l'utilisateur se verra ainsi présenté dans la div prévue le nom, le noméro dans le pokédex, les types, les noms de capacités, le poids et la taille de ce pokémon. Il y aura également l'image du pokémon, qui est présente en tant qu'URL dans le retour JSON des informations d'un pokémon
*/

const BASE_POKEMON_API_URL = "https://pokeapi.co/api/v2/";
let regionsResult = [];

const fetchAllLocations = async () => {
  try {
    const response = await fetch(BASE_POKEMON_API_URL + "pokedex");
    if (response.status === 200) {
      const data = await response.json();
      regionsResult = data.results;

      for (const key in regionsResult) {
        const region = `${regionsResult[key].name}`;
        const url = `${regionsResult[key].url}`;
        // console.log(region);
        //console.log(url);

        const response2 = await fetch(url);
        if (response2.status === 200) {
          const data2 = await response2.json();
          const pokedexResult = data2.pokemon_entries
          const tablesPokemonSpesies = pokedexResult.map((info) => ({ pokemonSpecies: info.pokemon_species }));
          console.log(tablesPokemonSpesies);
          
          
          // }
          // let pokemonSpecies = `${pokedexResult[key].pokemon_species}`;
          // console.log(pokemonSpecies);
        
        } else {
          throw new Error("erreur2");
        }
      }
     
    } else {
      throw new Error("Le serveur ne peut pas traiter la requête");
    }
  } catch (err) {
    console.log(err);
    //throw new Error("Il y a eu un soucis");
    throw new Error(err);
  }
};

document.addEventListener("DOMContentLoaded", async () => {
  // const selectResult = document.querySelector("select#generation");
  // const selectName = document.querySelector("select#pokemon-name");

  await fetchAllLocations();
});
